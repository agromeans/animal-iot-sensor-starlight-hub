from configparser import ConfigParser
from lib.logger_opt import *
import os

def init_share_config(share_config_file):
    init_time = '2000-01-01-00-00-00'
    share_config = ConfigParser()
    
    if not os.path.isfile(share_config_file):
        share_config['param'] = {
            'sensor_last_capture_time': init_time,
            'sensor_last_save_image_time': init_time
        }
        
        with open(share_config_file, 'w') as config_file:
            share_config.write(config_file)
    else:
        share_config.read(share_config_file)
        
    return share_config
    
config_file = './config.ini'
share_config_file = './share/config.ini'

config = ConfigParser()
config.read(config_file)
share_config = init_share_config(share_config_file)

version = ''

path_save_raw_dir = ''
path_save_heatmap_dir = ''
path_save_raw_left_dir = ''
path_save_raw_right_dir = ''
path_save_flir_rgb_dir = ''
path_save_flir_raw_dir = ''
path_save_raw_modified_dir = ''
path_iml_crop_param = ''

api_dualcam_rectify = ''
api_dualcam_rectify_and_pointcloud = ''
api_ai_service = ''
api_upload_record = ''

param_thermal_adjust = ''

param_capture_interval = '' 
param_save_image_interval = ''

param_last_capture_time = ''
param_last_save_image_time = ''

def write_share_config_last_capture_time(share_config, last_capture_time):
    share_config.read(share_config_file, encoding='UTF-8')
    share_config['param']['sensor_last_capture_time'] = last_capture_time
    with open(share_config_file, 'w') as config_file:
        share_config.write(config_file)
        
def update_last_capture_time_and_write_to_file(new_capture_time):
    global param_last_capture_time, share_config
    try:
        param_last_capture_time = new_capture_time 
        write_share_config_last_capture_time(share_config, new_capture_time)
    except Exception as e:
        logger.error(str(e))
        
def write_share_config_last_save_image_time(share_config, last_save_image_time):
    share_config.read(share_config_file, encoding='UTF-8')
    share_config['param']['sensor_last_save_image_time'] = last_save_image_time
    with open(share_config_file, 'w') as config_file:
        share_config.write(config_file)
        
def update_last_save_image_time_and_write_to_file(new_save_image_time):
    global param_last_save_image_time, share_config
    try:
        param_last_save_image_time = new_save_image_time
        write_share_config_last_save_image_time(share_config, new_save_image_time)
    except Exception as e:
        logger.error(str(e))
        
def get_version():
    return version
    
def check_share_config_section():
    init_time = '2000-01-01-00-00-00'
    
    if not share_config.has_section('param'):
        share_config.add_section('param')
        
    try:
        share_config.get('param', 'sensor_last_capture_time')
    except:
        share_config.set('param', 'sensor_last_capture_time', init_time)
        
    try:
        share_config.get('param', 'sensor_last_save_image_time')
    except:
        share_config.set('param', 'sensor_last_save_image_time', init_time)
        
    share_config.write(open(share_config_file, 'w'))
    
def check_config_section():
    if not config.has_section('common'):
        config.add_section('common')
        
    if not config.has_section('path'):
        config.add_section('path')
        
    if not config.has_section('api'):
        config.add_section('api')
        
    if not config.has_section('param'):
        config.add_section('param')
        
    config.write(open(config_file, 'w'))
    
def get_config():
    global version, path_save_raw_dir, path_save_heatmap_dir, path_save_raw_left_dir, path_save_raw_right_dir, path_save_flir_rgb_dir, path_save_flir_raw_dir, path_save_raw_modified_dir, path_iml_crop_param, api_dualcam_rectify ,api_dualcam_rectify_and_pointcloud, api_ai_service, api_upload_record, param_thermal_adjust, param_capture_interval, param_save_image_interval ,param_last_capture_time, param_last_save_image_time
    
    try:
        version = config.get('common', 'version')
    except Exception as e:
        logger.warning(e)
        version = ''
        
    try:
        path_save_raw_dir = config.get('path', 'save_raw_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_dir = ''
        
    try:
        path_save_heatmap_dir = config.get('path', 'save_heatmap_dir')
    except Exception as e:
        logger.warning(e)
        path_save_heatmap_dir = ''
        
    try:
        path_save_raw_left_dir = config.get('path', 'save_raw_left_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_left_dir = ''
        
    try:
        path_save_raw_right_dir = config.get('path', 'save_raw_right_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_right_dir = ''
        
    try:
        path_save_flir_rgb_dir = config.get('path', 'save_flir_rgb_dir')
    except Exception as e:
        logger.warning(e)
        path_save_flir_rgb_dir = ''
        
    try:
        path_save_flir_raw_dir = config.get('path', 'save_flir_raw_dir')
    except Exception as e:
        logger.warning(e)
        path_save_flir_raw_dir = ''
        
    try:
        path_save_raw_modified_dir = config.get('path', 'save_raw_modified_dir')
    except Exception as e:
        logger.warning(e)
        path_save_raw_modified_dir = ''
        
    try:
        path_iml_crop_param = config.get('path', 'iml_crop_param')
    except Exception as e:
        logger.warning(e)
        path_iml_crop_param = ''
        
    try:
        api_dualcam_rectify = config.get('api', 'dualcam_rectify')
    except Exception as e:
        logger.warning(e)
        api_dualcam_rectify = ''
        
    try:
        api_dualcam_rectify_and_pointcloud = config.get('api', 'dualcam_rectify_and_pointcloud')
    except Exception as e:
        logger.warning(e)
        api_dualcam_rectify_and_pointcloud = ''
        
    try:
        api_ai_service = config.get('api', 'ai_service')
    except Exception as e:
        logger.warning(e)
        api_ai_service = ''
        
    try:
        api_upload_record = config.get('api', 'upload_record')
    except Exception as e:
        logger.warning(e)
        api_upload_record = ''
        
    try:
        param_thermal_adjust = int(share_config.get('param', 'thermal_adjust'))
    except Exception as e:
        param_thermal_adjust = ''
        
    try:
        param_capture_interval = int(config.get('param', 'capture_interval'))
    except Exception as e:
        logger.warning(e)
        param_capture_interval = '' 
        
    try:
        param_last_capture_time = share_config.get('param', 'sensor_last_capture_time')
    except Exception as e:
        logger.warning(e)
        param_last_capture_time = '' 
        
    try:
        param_save_image_interval = int(config.get('param', 'save_image_interval'))
    except Exception as e:
        logger.warning(e)
        param_save_image_interval = '' 
        
    try:
        param_last_save_image_time = share_config.get('param', 'sensor_last_save_image_time')
    except Exception as e:
        logger.warning(e)
        param_last_save_image_time = '' 
        
def reload_config():
    check_share_config_section()
    check_config_section()
    get_config()
    