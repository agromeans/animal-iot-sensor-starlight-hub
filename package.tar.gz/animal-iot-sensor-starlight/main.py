from flask import Flask, request, jsonify
import config
import argparse
import requests
import lib.utils as utils
import lib.opt as opt
from lib.engine import SensorEngine
from lib.logger_opt import logger
from lib.exception_opt import ExceptionCommon

app = Flask(__name__)
requests.packages.urllib3.disable_warnings()

@app.before_request
def before_request():
    logger.info("'{path}' start serving remote ip: {ip}".format(path=request.path, ip=request.remote_addr))

@app.route("/get_all_sensor")
def get_all_sensor():
    now_time_str = utils.get_UTC_time_str()
    last_capture_time_str = config.param_last_capture_time 
    
    if utils.X_minus_1_min_later(now_time_str, last_capture_time_str, config.param_capture_interval):
        sensor_engine = SensorEngine()
        _, main_cat, ai_objs, _, ground_temp_info = sensor_engine.health_simulate()
        lux_value = None
        sensor_record = utils.sensor_record_formating(lux_value, main_cat, ai_objs, ground_temp_info)
        config.update_last_capture_time_and_write_to_file(now_time_str)
        utils.http_post_request(config.api_upload_record, json_input=sensor_record)
    else:
        logger.info(f'Skip capture. Time interval <= {config.param_capture_interval} minutes.')
        
    respond = dict(status_code=200, message='')
    return jsonify(respond), 200

@app.route("/detect/depth", methods=['GET'])
def horizontal_test():
    now_time_str = utils.get_UTC_time_str()
    save_image = request.args.get('save_image')
    
    try:
        center_depth, horizontal = opt.horizontal_test(now_time_str, save_image)
    except Exception as e:
        raise ExceptionCommon(message='error in horizontal_test func' + str(e))
        
    if save_image:
        utils.http_post_request(config.api_upload_record, {})
        
    message = {
        "center": center_depth,
        "horizontal": horizontal
        }
        
    respond = dict(status_code=200, message=message)
    return jsonify(respond), 200

@app.route("/version")
def get_version():
    return config.version

@app.errorhandler(ExceptionCommon)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response
    
@app.errorhandler(404)
def page_not_found(error):
    response = dict(status_code=404, message="404 Not Found")
    return jsonify(response), 404
    
@app.errorhandler(500)
def handle_500(error):
    response = dict(status_code=500, message="500 Error")
    return jsonify(response), 500

if __name__ == "__main__":
    config.reload_config()
    
    parse = argparse.ArgumentParser()
    parse.add_argument('-v', '--version', action='version', version=config.get_version(), help='Display version')
    parse.parse_args()

    logger.info('====The program is starting====')

    app.run(host='0.0.0.0', port=5081, threaded=False)
